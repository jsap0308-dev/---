
  # 한자 학습 게임앱 개발

  This is a code bundle for 한자 학습 게임앱 개발. The original project is available at https://www.figma.com/design/ge8G3CfrXbrq5Gghoz32L4/%ED%95%9C%EC%9E%90-%ED%95%99%EC%8A%B5-%EA%B2%8C%EC%9E%84%EC%95%B1-%EA%B0%9C%EB%B0%9C.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  