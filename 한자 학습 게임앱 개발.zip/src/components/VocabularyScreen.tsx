import { useState, useMemo } from 'react';
import { Search, Filter, Volume2, Star, BookOpen, ArrowLeft } from 'lucide-react';
import { Character, Radical, VocabularyFilter } from '../lib/types';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface VocabularyScreenProps {
  characters: Character[];
  radicals: Radical[];
  learnedCharacters?: string[];
  onBack: () => void;
  onStudyCharacter: (characterId: string) => void;
}

export function VocabularyScreen({ 
  characters, 
  radicals, 
  learnedCharacters = [], 
  onBack,
  onStudyCharacter 
}: VocabularyScreenProps) {
  const [filter, setFilter] = useState<VocabularyFilter>({});
  const [currentTab, setCurrentTab] = useState('all');

  // 발음 재생 함수 (모의)
  const playPronunciation = (character: Character) => {
    // 실제 구현에서는 Web Speech API나 오디오 파일을 사용
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(character.pronunciation.pinyin);
      utterance.lang = 'zh-CN';
      utterance.rate = 0.8;
      speechSynthesis.speak(utterance);
    }
  };

  // 필터링된 한자 목록
  const filteredCharacters = useMemo(() => {
    let result = [...characters];

    // 텍스트 검색
    if (filter.search) {
      const searchTerm = filter.search.toLowerCase();
      result = result.filter(char => 
        char.character.includes(searchTerm) ||
        char.meaning.korean.toLowerCase().includes(searchTerm) ||
        char.meaning.english.toLowerCase().includes(searchTerm) ||
        char.pronunciation.pinyin.toLowerCase().includes(searchTerm) ||
        char.pronunciation.korean.toLowerCase().includes(searchTerm)
      );
    }

    // 부수 필터
    if (filter.radical) {
      result = result.filter(char => char.radical_id === filter.radical);
    }

    // 급수 필터
    if (filter.grade) {
      result = result.filter(char => char.grade === filter.grade);
    }

    // 난이도 필터
    if (filter.difficulty) {
      result = result.filter(char => char.difficulty === filter.difficulty);
    }

    // 태그 필터
    if (filter.tags && filter.tags.length > 0) {
      result = result.filter(char => 
        char.tags?.some(tag => filter.tags?.includes(tag))
      );
    }

    // 학습 상태 필터
    if (filter.learned !== undefined) {
      result = result.filter(char => 
        learnedCharacters.includes(char.id) === filter.learned
      );
    }

    // 탭별 필터링
    if (currentTab === 'learned') {
      result = result.filter(char => learnedCharacters.includes(char.id));
    } else if (currentTab === 'unlearned') {
      result = result.filter(char => !learnedCharacters.includes(char.id));
    }

    return result;
  }, [characters, filter, learnedCharacters, currentTab]);

  // 급수별 그룹화
  const charactersByGrade = useMemo(() => {
    const grouped: Record<number, Character[]> = {};
    filteredCharacters.forEach(char => {
      const grade = char.grade || 8;
      if (!grouped[grade]) {
        grouped[grade] = [];
      }
      grouped[grade].push(char);
    });
    return grouped;
  }, [filteredCharacters]);

  // 전체 태그 목록
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    characters.forEach(char => {
      char.tags?.forEach(tag => tags.add(tag));
    });
    return Array.from(tags);
  }, [characters]);

  const CharacterCard = ({ character }: { character: Character }) => {
    const radical = radicals.find(r => r.id === character.radical_id);
    const isLearned = learnedCharacters.includes(character.id);

    return (
      <Card className="hover:shadow-md transition-shadow cursor-pointer" 
            onClick={() => onStudyCharacter(character.id)}>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-3xl font-medium">{character.character}</span>
              {isLearned && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
            </div>
            <div className="flex items-center gap-1">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  playPronunciation(character);
                }}
              >
                <Volume2 className="w-4 h-4" />
              </Button>
              <Badge variant="outline">{character.grade}급</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div>
              <p className="font-medium">{character.meaning.korean}</p>
              <p className="text-sm text-muted-foreground">{character.meaning.english}</p>
            </div>
            
            <div className="text-sm">
              <p><span className="font-medium">발음:</span> {character.pronunciation.korean} ({character.pronunciation.pinyin})</p>
              {radical && (
                <p><span className="font-medium">부수:</span> {radical.glyph} ({radical.meaning})</p>
              )}
            </div>

            <div className="flex flex-wrap gap-1">
              {character.tags?.map(tag => (
                <Badge key={tag} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
              <Badge variant={character.difficulty === 1 ? 'default' : character.difficulty <= 3 ? 'secondary' : 'destructive'} className="text-xs">
                난이도 {character.difficulty}
              </Badge>
            </div>

            {character.examples && character.examples.length > 0 && (
              <div className="text-sm">
                <p className="font-medium">예시:</p>
                <p className="text-muted-foreground">{character.examples.join(', ')}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-background p-4">
      {/* 헤더 */}
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          돌아가기
        </Button>
        <div className="flex items-center gap-2">
          <BookOpen className="w-6 h-6" />
          <h1 className="text-2xl font-medium">한자 단어장</h1>
        </div>
      </div>

      {/* 필터 섹션 */}
      <div className="mb-6 space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="한자, 뜻, 발음으로 검색..."
              value={filter.search || ''}
              onChange={(e) => setFilter(prev => ({ ...prev, search: e.target.value }))}
              className="pl-10"
            />
          </div>
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            필터
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Select value={filter.grade?.toString() || ''} onValueChange={(value) => 
            setFilter(prev => ({ ...prev, grade: value ? parseInt(value) : undefined }))
          }>
            <SelectTrigger>
              <SelectValue placeholder="급수" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">전체</SelectItem>
              <SelectItem value="1">1급</SelectItem>
              <SelectItem value="2">2급</SelectItem>
              <SelectItem value="3">3급</SelectItem>
              <SelectItem value="4">4급</SelectItem>
              <SelectItem value="5">5급</SelectItem>
              <SelectItem value="6">6급</SelectItem>
              <SelectItem value="7">7급</SelectItem>
              <SelectItem value="8">8급</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filter.radical || ''} onValueChange={(value) => 
            setFilter(prev => ({ ...prev, radical: value || undefined }))
          }>
            <SelectTrigger>
              <SelectValue placeholder="부수" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">전체</SelectItem>
              {radicals.map(radical => (
                <SelectItem key={radical.id} value={radical.id}>
                  {radical.glyph} {radical.meaning}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filter.difficulty?.toString() || ''} onValueChange={(value) => 
            setFilter(prev => ({ ...prev, difficulty: value ? parseInt(value) : undefined }))
          }>
            <SelectTrigger>
              <SelectValue placeholder="난이도" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">전체</SelectItem>
              <SelectItem value="1">1 (쉬움)</SelectItem>
              <SelectItem value="2">2</SelectItem>
              <SelectItem value="3">3</SelectItem>
              <SelectItem value="4">4</SelectItem>
              <SelectItem value="5">5 (어려움)</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filter.tags?.[0] || ''} onValueChange={(value) => 
            setFilter(prev => ({ ...prev, tags: value ? [value] : undefined }))
          }>
            <SelectTrigger>
              <SelectValue placeholder="테마" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">전체</SelectItem>
              {allTags.map(tag => (
                <SelectItem key={tag} value={tag}>
                  {tag}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 탭 */}
      <Tabs value={currentTab} onValueChange={setCurrentTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">전체 ({characters.length})</TabsTrigger>
          <TabsTrigger value="learned">학습완료 ({learnedCharacters.length})</TabsTrigger>
          <TabsTrigger value="unlearned">미학습 ({characters.length - learnedCharacters.length})</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* 결과 통계 */}
      <div className="mb-4">
        <p className="text-sm text-muted-foreground">
          {filteredCharacters.length}개의 한자가 검색되었습니다
        </p>
      </div>

      {/* 한자 목록 */}
      {Object.keys(charactersByGrade).length > 0 ? (
        <div className="space-y-6">
          {Object.entries(charactersByGrade)
            .sort(([a], [b]) => parseInt(a) - parseInt(b))
            .map(([grade, chars]) => (
              <div key={grade}>
                <h2 className="text-lg font-medium mb-3">{grade}급 한자 ({chars.length}개)</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {chars.map(character => (
                    <CharacterCard key={character.id} character={character} />
                  ))}
                </div>
              </div>
            ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <BookOpen className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <p className="text-lg font-medium mb-2">검색 결과가 없습니다</p>
          <p className="text-muted-foreground">다른 검색 조건을 시도해보세요</p>
        </div>
      )}
    </div>
  );
}