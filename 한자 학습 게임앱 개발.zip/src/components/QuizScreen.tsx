import { useState, useEffect } from 'react';
import { QuizCard } from './QuizCard';
import { ProgressBar } from './ProgressBar';
import { SessionComplete } from './SessionComplete';
import { Button } from './ui/button';
import { Quiz, Character, Radical } from '../lib/types';

interface QuizScreenProps {
  quizzes: Quiz[];
  characters: Character[];
  radicals: Radical[];
  onComplete: (results: QuizResult[]) => void;
  onBack: () => void;
}

interface QuizResult {
  quiz: Quiz;
  selectedOption: number;
  isCorrect: boolean;
  timeSpent: number;
}

export function QuizScreen({ 
  quizzes, 
  characters, 
  radicals, 
  onComplete, 
  onBack 
}: QuizScreenProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [results, setResults] = useState<QuizResult[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [startTime, setStartTime] = useState(Date.now());
  const [questionStartTime, setQuestionStartTime] = useState(Date.now());
  const [isComplete, setIsComplete] = useState(false);

  const currentQuiz = quizzes[currentIndex];
  const currentCharacter = characters.find(c => c.id === currentQuiz?.character_id);
  const currentRadical = radicals.find(r => r.id === currentCharacter?.radical_id);

  useEffect(() => {
    setQuestionStartTime(Date.now());
  }, [currentIndex]);

  const handleAnswer = (option: number) => {
    if (showResult) return;
    
    setSelectedOption(option);
    setShowResult(true);

    const timeSpent = Date.now() - questionStartTime;
    const isCorrect = option === currentQuiz.correct_answer;

    const result: QuizResult = {
      quiz: currentQuiz,
      selectedOption: option,
      isCorrect,
      timeSpent
    };

    setResults(prev => [...prev, result]);
  };

  const handleNext = () => {
    if (currentIndex < quizzes.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setShowResult(false);
      setSelectedOption(null);
    } else {
      setIsComplete(true);
    }
  };

  const handleSessionComplete = () => {
    onComplete(results);
  };

  const handleReviewMistakes = () => {
    const mistakes = results.filter(r => !r.isCorrect);
    const mistakeQuizzes = mistakes.map(m => m.quiz);
    // Reset to review only mistakes
    setCurrentIndex(0);
    setResults([]);
    setShowResult(false);
    setSelectedOption(null);
    setIsComplete(false);
    // This would ideally filter the quizzes to only mistakes, but for simplicity we'll just restart
  };

  if (!currentQuiz || !currentCharacter || !currentRadical) {
    return (
      <div className="max-w-md mx-auto p-4">
        <p>로딩 중...</p>
      </div>
    );
  }

  if (isComplete) {
    const correctCount = results.filter(r => r.isCorrect).length;
    const totalTime = (Date.now() - startTime) / 1000;
    const xpEarned = correctCount * 10 + (correctCount === quizzes.length ? 50 : 0);
    const coinsEarned = correctCount * 5;

    return (
      <div className="max-w-md mx-auto p-4">
        <SessionComplete
          totalQuestions={quizzes.length}
          correctAnswers={correctCount}
          timeSpent={totalTime}
          xpEarned={xpEarned}
          coinsEarned={coinsEarned}
          onContinue={handleSessionComplete}
          onReviewMistakes={handleReviewMistakes}
        />
      </div>
    );
  }

  const correctCount = results.filter(r => r.isCorrect).length;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          ← 뒤로
        </Button>
        <h2 className="font-medium">한자 퀴즈</h2>
        <div className="w-16"> {/* Spacer */}
        </div>
      </div>

      {/* Progress */}
      <ProgressBar
        current={results.length}
        total={quizzes.length}
        correct={correctCount}
      />

      {/* Quiz Card */}
      <QuizCard
        quiz={currentQuiz}
        character={currentCharacter}
        radical={currentRadical}
        onAnswer={handleAnswer}
        showResult={showResult}
        selectedOption={selectedOption}
      />

      {/* Next Button */}
      {showResult && (
        <div className="flex justify-center">
          <Button onClick={handleNext} className="px-8">
            {currentIndex < quizzes.length - 1 ? '다음 문제' : '결과 보기'}
          </Button>
        </div>
      )}

      {/* Question Counter */}
      <div className="text-center text-sm text-muted-foreground">
        {currentIndex + 1} / {quizzes.length}
      </div>
    </div>
  );
}