import { useState } from 'react';
import { Trophy, Lock, Star, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { Achievement, UserProgress } from '../lib/types';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface AchievementScreenProps {
  achievements: Achievement[];
  userProgress: UserProgress;
  onBack: () => void;
}

export function AchievementScreen({ achievements, userProgress, onBack }: AchievementScreenProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');

  // 성취 상태별 분류
  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const lockedAchievements = achievements.filter(a => !a.unlocked);
  
  // 카테고리별 분류
  const categorizedAchievements = {
    streak: achievements.filter(a => a.condition.type === 'streak'),
    learning: achievements.filter(a => a.condition.type === 'total_learned'),
    performance: achievements.filter(a => ['accuracy', 'speed'].includes(a.condition.type)),
    grade: achievements.filter(a => a.condition.type === 'grade_complete')
  };

  // 진행률 계산
  const calculateProgress = (achievement: Achievement): number => {
    if (achievement.unlocked) return 100;
    
    const { type, target } = achievement.condition;
    let current = 0;

    switch (type) {
      case 'streak':
        current = userProgress.daily_streak;
        break;
      case 'total_learned':
        current = userProgress.total_learned;
        break;
      case 'accuracy':
        // 모의 정확도 (실제로는 별도 계산 필요)
        current = 85;
        break;
      case 'speed':
        // 모의 속도 (실제로는 별도 계산 필요)
        current = 4000;
        break;
      case 'grade_complete':
        // 모의 급수 완료 상태 (실제로는 별도 계산 필요)
        current = target > 5 ? 1 : 0;
        break;
    }

    return Math.min((current / target) * 100, 100);
  };

  const AchievementCard = ({ achievement }: { achievement: Achievement }) => {
    const progress = calculateProgress(achievement);
    const isUnlocked = achievement.unlocked;

    return (
      <Card className={`transition-all ${isUnlocked ? 'border-yellow-200 bg-yellow-50/50' : 'opacity-75'}`}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className={`text-2xl p-2 rounded-lg ${isUnlocked ? 'bg-yellow-100' : 'bg-gray-100'}`}>
                {isUnlocked ? achievement.icon : <Lock className="w-6 h-6 text-gray-400" />}
              </div>
              <div>
                <CardTitle className={`${isUnlocked ? 'text-yellow-700' : 'text-gray-600'}`}>
                  {achievement.title}
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {achievement.description}
                </p>
              </div>
            </div>
            {isUnlocked && (
              <CheckCircle2 className="w-5 h-5 text-yellow-600" />
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {!isUnlocked && (
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>진행률</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}
            
            <div className="flex items-center justify-between">
              <Badge variant={isUnlocked ? 'default' : 'secondary'}>
                +{achievement.xp_reward} XP
              </Badge>
              {isUnlocked && achievement.unlocked_date && (
                <span className="text-xs text-muted-foreground">
                  {achievement.unlocked_date.toLocaleDateString()}
                </span>
              )}
            </div>

            {!isUnlocked && (
              <div className="text-sm text-muted-foreground">
                {getConditionText(achievement, progress)}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const getConditionText = (achievement: Achievement, progress: number): string => {
    const { type, target } = achievement.condition;
    const current = Math.round((progress / 100) * target);

    switch (type) {
      case 'streak':
        return `연속 학습: ${current}/${target}일`;
      case 'total_learned':
        return `학습한 한자: ${current}/${target}개`;
      case 'accuracy':
        return `정확도: ${current}/${target}%`;
      case 'speed':
        return `평균 답변 시간: ${(current/1000).toFixed(1)}/${(target/1000).toFixed(1)}초`;
      case 'grade_complete':
        return `${target}급 한자 완주`;
      default:
        return '';
    }
  };

  const getDisplayAchievements = () => {
    switch (selectedCategory) {
      case 'unlocked':
        return unlockedAchievements;
      case 'locked':
        return lockedAchievements;
      case 'streak':
        return categorizedAchievements.streak;
      case 'learning':
        return categorizedAchievements.learning;
      case 'performance':
        return categorizedAchievements.performance;
      case 'grade':
        return categorizedAchievements.grade;
      default:
        return achievements;
    }
  };

  const totalXP = unlockedAchievements.reduce((sum, a) => sum + a.xp_reward, 0);

  return (
    <div className="min-h-screen bg-background p-4">
      {/* 헤더 */}
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          돌아가기
        </Button>
        <div className="flex items-center gap-2">
          <Trophy className="w-6 h-6 text-yellow-600" />
          <h1 className="text-2xl font-medium">성취</h1>
        </div>
      </div>

      {/* 통계 요약 */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-medium text-yellow-600">{unlockedAchievements.length}</div>
            <div className="text-sm text-muted-foreground">획득한 배지</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-medium">{achievements.length}</div>
            <div className="text-sm text-muted-foreground">전체 배지</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-medium text-blue-600">{totalXP}</div>
            <div className="text-sm text-muted-foreground">배지 XP</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-medium text-green-600">
              {Math.round((unlockedAchievements.length / achievements.length) * 100)}%
            </div>
            <div className="text-sm text-muted-foreground">완성률</div>
          </CardContent>
        </Card>
      </div>

      {/* 탭 */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-6">
        <TabsList className="grid w-full grid-cols-3 sm:grid-cols-6">
          <TabsTrigger value="all">전체</TabsTrigger>
          <TabsTrigger value="unlocked">
            <Star className="w-4 h-4 mr-1" />
            획득
          </TabsTrigger>
          <TabsTrigger value="locked">
            <Lock className="w-4 h-4 mr-1" />
            미획득
          </TabsTrigger>
          <TabsTrigger value="streak">연속학습</TabsTrigger>
          <TabsTrigger value="learning">학습량</TabsTrigger>
          <TabsTrigger value="performance">실력</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* 성취 목록 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {getDisplayAchievements().map(achievement => (
          <AchievementCard key={achievement.id} achievement={achievement} />
        ))}
      </div>

      {getDisplayAchievements().length === 0 && (
        <div className="text-center py-12">
          <Trophy className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <p className="text-lg font-medium mb-2">해당 카테고리에 성취가 없습니다</p>
          <p className="text-muted-foreground">다른 카테고리를 확인해보세요</p>
        </div>
      )}
    </div>
  );
}