import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

interface SessionCompleteProps {
  totalQuestions: number;
  correctAnswers: number;
  timeSpent: number;
  xpEarned: number;
  coinsEarned: number;
  onContinue: () => void;
  onReviewMistakes: () => void;
}

export function SessionComplete({
  totalQuestions,
  correctAnswers,
  timeSpent,
  xpEarned,
  coinsEarned,
  onContinue,
  onReviewMistakes
}: SessionCompleteProps) {
  const accuracy = (correctAnswers / totalQuestions) * 100;
  const averageTime = timeSpent / totalQuestions;

  const getPerformanceMessage = () => {
    if (accuracy >= 90) return { emoji: '🎉', message: '완벽합니다!', color: 'text-green-600' };
    if (accuracy >= 80) return { emoji: '👍', message: '훌륭해요!', color: 'text-blue-600' };
    if (accuracy >= 70) return { emoji: '👌', message: '잘했어요!', color: 'text-orange-600' };
    return { emoji: '💪', message: '연습이 필요해요!', color: 'text-red-600' };
  };

  const performance = getPerformanceMessage();

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="text-4xl mb-2">{performance.emoji}</div>
        <CardTitle className={performance.color}>{performance.message}</CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="space-y-1">
            <div className="text-2xl font-medium">{correctAnswers}/{totalQuestions}</div>
            <div className="text-sm text-muted-foreground">정답률</div>
          </div>
          <div className="space-y-1">
            <div className="text-2xl font-medium">{accuracy.toFixed(0)}%</div>
            <div className="text-sm text-muted-foreground">정확도</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="space-y-1">
            <div className="text-lg font-medium">{Math.round(averageTime)}초</div>
            <div className="text-xs text-muted-foreground">평균 소요시간</div>
          </div>
          <div className="space-y-1">
            <div className="text-lg font-medium">{Math.round(timeSpent / 60)}분</div>
            <div className="text-xs text-muted-foreground">총 시간</div>
          </div>
        </div>

        <div className="flex justify-center gap-4">
          <Badge variant="secondary" className="px-3 py-1">
            +{xpEarned} XP
          </Badge>
          <Badge variant="secondary" className="px-3 py-1">
            +{coinsEarned} 코인
          </Badge>
        </div>

        <div className="space-y-3">
          <Button onClick={onContinue} className="w-full">
            다음 학습 세트
          </Button>
          
          {correctAnswers < totalQuestions && (
            <Button 
              onClick={onReviewMistakes} 
              variant="outline" 
              className="w-full"
            >
              틀린 문제 복습하기
            </Button>
          )}
        </div>

        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            오늘 {totalQuestions}개의 한자를 학습했습니다!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}