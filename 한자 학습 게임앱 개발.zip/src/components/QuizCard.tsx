import { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { Quiz, Character, Radical } from '../lib/types';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { audioManager } from '../lib/audio';

interface QuizCardProps {
  quiz: Quiz;
  character: Character;
  radical: Radical;
  onAnswer: (selectedOption: number) => void;
  showResult?: boolean;
  selectedOption?: number;
}

export function QuizCard({ 
  quiz, 
  character, 
  radical, 
  onAnswer, 
  showResult = false,
  selectedOption 
}: QuizCardProps) {
  const [selected, setSelected] = useState<number | null>(selectedOption ?? null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleOptionSelect = (optionIndex: number) => {
    if (showResult) return;
    setSelected(optionIndex);
    onAnswer(optionIndex);
  };

  const handlePlayPronunciation = async (language: 'chinese' | 'korean' | 'japanese' = 'chinese') => {
    if (isPlaying) return;
    
    try {
      setIsPlaying(true);
      await audioManager.playPronunciation(character, language);
    } catch (error) {
      console.error('Failed to play pronunciation:', error);
    } finally {
      setTimeout(() => setIsPlaying(false), 1000);
    }
  };

  const getOptionStyle = (index: number) => {
    if (!showResult && selected !== index) return 'border-border hover:border-primary';
    if (!showResult && selected === index) return 'border-primary bg-primary/5';
    
    if (showResult) {
      if (index === quiz.correct_answer) return 'border-green-500 bg-green-50 text-green-700';
      if (index === selected && index !== quiz.correct_answer) {
        return 'border-red-500 bg-red-50 text-red-700';
      }
      return 'border-border opacity-50';
    }
    
    return 'border-border';
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center space-y-4">
        <div className="flex items-center justify-center gap-2">
          <Badge variant="secondary" className="text-sm">
            {radical.glyph} {radical.meaning}
          </Badge>
        </div>
        
        <div className="flex items-center justify-center gap-4">
          <div className="text-6xl font-light text-primary">
            {character.character}
          </div>
          
          {/* 발음 재생 버튼들 */}
          <div className="flex flex-col gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              onClick={() => handlePlayPronunciation('chinese')}
              disabled={isPlaying}
              title={`중국어 발음: ${character.pronunciation.pinyin}`}
            >
              {isPlaying ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            <span className="text-xs text-muted-foreground">
              {character.pronunciation.pinyin}
            </span>
          </div>
        </div>
        
        <CardTitle className="text-lg">{quiz.question}</CardTitle>
        
        {quiz.radical_hint && (
          <div className="text-sm text-muted-foreground bg-muted p-2 rounded-lg">
            💡 힌트: {quiz.radical_hint}
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-3">
        {quiz.options.map((option, index) => (
          <Button
            key={index}
            variant="outline"
            className={`w-full p-4 h-auto text-left justify-start border-2 transition-colors ${getOptionStyle(index)}`}
            onClick={() => handleOptionSelect(index)}
            disabled={showResult}
          >
            <span className="w-6 h-6 rounded-full border border-current flex items-center justify-center mr-3 text-sm">
              {String.fromCharCode(65 + index)}
            </span>
            {option}
          </Button>
        ))}

        {showResult && (
          <div className="mt-6 p-4 bg-muted rounded-lg">
            <h4 className="font-medium mb-2">해설</h4>
            <p className="text-sm text-muted-foreground">{quiz.explanation}</p>
            
            {/* 추가 발음 정보 */}
            <div className="mt-3 pt-3 border-t border-border">
              <h5 className="font-medium text-sm mb-2">발음</h5>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => handlePlayPronunciation('korean')}
                    disabled={isPlaying}
                  >
                    <Volume2 className="w-3 h-3" />
                  </Button>
                  <span>한국어: {character.pronunciation.korean}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => handlePlayPronunciation('japanese')}
                    disabled={isPlaying}
                  >
                    <Volume2 className="w-3 h-3" />
                  </Button>
                  <span>일본어: {character.pronunciation.japanese_on}</span>
                </div>
              </div>
            </div>
            
            {character.etymology && (
              <div className="mt-3 pt-3 border-t border-border">
                <h5 className="font-medium text-sm mb-1">어원</h5>
                <p className="text-sm text-muted-foreground">{character.etymology}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}