import { Progress } from './ui/progress';

interface ProgressBarProps {
  current: number;
  total: number;
  correct: number;
  className?: string;
}

export function ProgressBar({ current, total, correct, className = '' }: ProgressBarProps) {
  const progress = (current / total) * 100;
  const accuracy = current > 0 ? (correct / current) * 100 : 0;

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex justify-between items-center text-sm">
        <span className="text-muted-foreground">
          진행률: {current}/{total}
        </span>
        <span className="text-muted-foreground">
          정답률: {accuracy.toFixed(0)}%
        </span>
      </div>
      
      <Progress value={progress} className="h-2" />
      
      <div className="flex justify-between items-center text-xs text-muted-foreground">
        <span>🎯 정답: {correct}</span>
        <span>❌ 오답: {current - correct}</span>
      </div>
    </div>
  );
}