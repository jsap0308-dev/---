import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { BookOpen, Trophy, Volume2 } from 'lucide-react';
import { UserProgress } from '../lib/types';

interface HomeScreenProps {
  userProgress: UserProgress;
  dueCards: number;
  newCards: number;
  onStartQuickMatch: () => void;
  onStartLearningSet: (theme: string) => void;
  onStartReview: () => void;
  onNavigateToVocabulary: () => void;
  onNavigateToAchievements: () => void;
}

export function HomeScreen({
  userProgress,
  dueCards,
  newCards,
  onStartQuickMatch,
  onStartLearningSet,
  onStartReview,
  onNavigateToVocabulary,
  onNavigateToAchievements
}: HomeScreenProps) {
  const [selectedTheme, setSelectedTheme] = useState<string>('');

  const themes = [
    { id: 'nature', name: '자연', emoji: '🌿', description: '물, 나무, 산 관련 한자' },
    { id: 'people', name: '사람', emoji: '👥', description: '인체, 관계 관련 한자' },
    { id: 'daily', name: '일상', emoji: '🏠', description: '생활, 도구 관련 한자' },
    { id: 'mixed', name: '종합', emoji: '🎯', description: '다양한 주제 혼합' }
  ];

  const levelProgress = (userProgress.weekly_xp % 1000) / 1000 * 100;
  const unlockedAchievements = userProgress.achievements?.filter(a => a.unlocked).length || 0;

  return (
    <div className="max-w-md mx-auto space-y-6 p-4">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-medium text-primary">부수로 배우는 한자</h1>
        <p className="text-muted-foreground">오늘도 한자 학습을 시작해보세요!</p>
      </div>

      {/* Quick Navigation */}
      <div className="grid grid-cols-2 gap-3">
        <Button 
          variant="outline" 
          className="h-16 flex-col gap-1"
          onClick={onNavigateToVocabulary}
        >
          <BookOpen className="w-5 h-5" />
          <span className="text-xs">단어장</span>
        </Button>
        <Button 
          variant="outline" 
          className="h-16 flex-col gap-1"
          onClick={onNavigateToAchievements}
        >
          <Trophy className="w-5 h-5" />
          <span className="text-xs">성취</span>
        </Button>
      </div>

      {/* User Progress */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">레벨 {userProgress.level}</CardTitle>
              <p className="text-sm text-muted-foreground">{userProgress.daily_streak}일 연속 학습</p>
            </div>
            <div className="text-right space-y-1">
              <Badge variant="secondary">{userProgress.coins} 코인</Badge>
              <div className="flex items-center gap-1">
                <Trophy className="w-3 h-3 text-yellow-600" />
                <span className="text-xs text-muted-foreground">{unlockedAchievements}개 배지</span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>주간 경험치</span>
              <span>{userProgress.weekly_xp}/1000 XP</span>
            </div>
            <Progress value={levelProgress} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Today's Study */}
      <Card>
        <CardHeader>
          <CardTitle>오늘의 학습</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="text-2xl font-medium text-blue-600">{dueCards}</div>
              <div className="text-sm text-blue-600">복습 대기</div>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <div className="text-2xl font-medium text-green-600">{newCards}</div>
              <div className="text-sm text-green-600">새로운 한자</div>
            </div>
          </div>

          <Button 
            onClick={onStartQuickMatch} 
            className="w-full"
            disabled={dueCards + newCards === 0}
          >
            퀵 매치 시작 (3분)
          </Button>
        </CardContent>
      </Card>

      {/* Learning Themes */}
      <Card>
        <CardHeader>
          <CardTitle>테마별 학습</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {themes.map((theme) => (
            <Button
              key={theme.id}
              variant={selectedTheme === theme.id ? "default" : "outline"}
              className="w-full h-auto p-3 justify-start"
              onClick={() => {
                setSelectedTheme(theme.id);
                onStartLearningSet(theme.id);
              }}
            >
              <div className="flex items-center gap-3">
                <span className="text-xl">{theme.emoji}</span>
                <div className="text-left">
                  <div className="font-medium">{theme.name}</div>
                  <div className="text-xs text-muted-foreground">{theme.description}</div>
                </div>
              </div>
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* Review Section */}
      {dueCards > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              📚 복습
              <Badge variant="destructive">{dueCards}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={onStartReview} variant="outline" className="w-full">
              복습 시작하기
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      <Card>
        <CardHeader>
          <CardTitle>학습 통계</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-medium">{userProgress.total_learned}</div>
              <div className="text-xs text-muted-foreground">학습한 한자</div>
            </div>
            <div>
              <div className="text-lg font-medium">{userProgress.daily_streak}</div>
              <div className="text-xs text-muted-foreground">연속 학습일</div>
            </div>
            <div>
              <div className="text-lg font-medium">{unlockedAchievements}</div>
              <div className="text-xs text-muted-foreground">획득 배지</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}