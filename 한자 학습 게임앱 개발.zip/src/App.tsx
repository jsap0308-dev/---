import { useState, useEffect } from 'react';
import { HomeScreen } from './components/HomeScreen';
import { QuizScreen } from './components/QuizScreen';
import { VocabularyScreen } from './components/VocabularyScreen';
import { AchievementScreen } from './components/AchievementScreen';
import { radicals, characters, quizzes, achievements } from './lib/data';
import { UserProgress, SRSCard, LearningSession, Achievement } from './lib/types';
import { createNewCard, updateCard, getDueCards, getNewCards } from './lib/srs';
import { checkAchievements, calculateSessionStats, checkGradeCompletion } from './lib/achievement';

type Screen = 'home' | 'quiz' | 'review' | 'vocabulary' | 'achievements';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [currentSession, setCurrentSession] = useState<LearningSession | null>(null);
  
  // User progress with achievements
  const [userProgress, setUserProgress] = useState<UserProgress>({
    total_learned: 24,
    daily_streak: 7,
    weekly_xp: 450,
    level: 3,
    coins: 150,
    badges: ['first_week', 'accuracy_master'],
    achievements: achievements.map(a => ({ ...a, unlocked: a.id === 'first_step' || a.id === 'week_warrior' }))
  });

  // Mock SRS cards - in real app this would be loaded from storage
  const [srsCards, setSrsCards] = useState<SRSCard[]>(() => {
    // Create some sample cards with different review states
    const cards = characters.slice(0, 8).map((char, index) => {
      const card = createNewCard(char.id);
      // Simulate some cards being due for review
      if (index < 3) {
        card.next_review = new Date(Date.now() - 24 * 60 * 60 * 1000); // Yesterday
        card.review_count = Math.floor(Math.random() * 5) + 1;
      }
      return card;
    });
    return cards;
  });

  const dueCards = getDueCards(srsCards);
  const newCards = getNewCards(srsCards, 5);
  const learnedCharacters = srsCards.filter(card => card.review_count > 0).map(card => card.character_id);

  const startQuickMatch = () => {
    // Create a quick 3-5 question session
    const availableQuizzes = [...quizzes];
    const sessionQuizzes = availableQuizzes.slice(0, Math.min(5, availableQuizzes.length));
    
    const session: LearningSession = {
      id: `session_${Date.now()}`,
      cards: sessionQuizzes,
      completed: 0,
      correct: 0,
      start_time: new Date()
    };

    setCurrentSession(session);
    setCurrentScreen('quiz');
  };

  const startLearningSet = (theme: string) => {
    // Create a themed learning session
    let themeQuizzes = [...quizzes];
    
    // Filter by theme (simplified - in real app would have better theme categorization)
    if (theme === 'nature') {
      themeQuizzes = quizzes.filter(q => {
        const char = characters.find(c => c.id === q.character_id);
        const radical = radicals.find(r => r.id === char?.radical_id);
        return ['water', 'tree', 'earth'].includes(radical?.id || '');
      });
    }

    const session: LearningSession = {
      id: `session_${Date.now()}`,
      cards: themeQuizzes.slice(0, 8),
      completed: 0,
      correct: 0,
      start_time: new Date(),
      theme
    };

    setCurrentSession(session);
    setCurrentScreen('quiz');
  };

  const startReview = () => {
    // Create a review session with due cards
    const dueCardIds = dueCards.map(card => card.character_id);
    const reviewQuizzes = quizzes.filter(q => dueCardIds.includes(q.character_id));

    const session: LearningSession = {
      id: `session_${Date.now()}`,
      cards: reviewQuizzes.slice(0, 10),
      completed: 0,
      correct: 0,
      start_time: new Date()
    };

    setCurrentSession(session);
    setCurrentScreen('quiz');
  };

  const handleQuizComplete = (results: any[]) => {
    // Update SRS cards based on results
    const updatedCards = [...srsCards];
    
    results.forEach(result => {
      const cardIndex = updatedCards.findIndex(card => 
        characters.find(c => c.id === card.character_id)?.id === result.quiz.character_id
      );
      
      if (cardIndex !== -1) {
        // Determine performance based on result
        let performance: 'again' | 'hard' | 'good' | 'easy';
        if (!result.isCorrect) {
          performance = 'again';
        } else if (result.timeSpent > 10000) { // More than 10 seconds
          performance = 'hard';
        } else if (result.timeSpent < 3000) { // Less than 3 seconds
          performance = 'easy';
        } else {
          performance = 'good';
        }

        updatedCards[cardIndex] = updateCard(updatedCards[cardIndex], performance);
      }
    });

    setSrsCards(updatedCards);

    // Calculate session statistics
    const sessionStats = calculateSessionStats(results, characters);
    const completedGrades = checkGradeCompletion(updatedCards, characters);
    
    // Check for new achievements
    const achievementCheck = checkAchievements(
      { ...userProgress, total_learned: userProgress.total_learned + results.filter(r => r.isCorrect).length },
      updatedCards,
      { ...sessionStats, completedGrades }
    );

    // Update user progress with new achievements and XP
    if (achievementCheck.newAchievements.length > 0 || achievementCheck.updatedAchievements.length > 0) {
      setUserProgress(prev => ({
        ...prev,
        total_learned: prev.total_learned + results.filter(r => r.isCorrect).length,
        weekly_xp: prev.weekly_xp + achievementCheck.totalXP,
        achievements: prev.achievements?.map(a => {
          const newAchievement = achievementCheck.newAchievements.find(na => na.id === a.id);
          const updatedAchievement = achievementCheck.updatedAchievements.find(ua => ua.id === a.id);
          return newAchievement || updatedAchievement || a;
        })
      }));

      // Show achievement notifications (in a real app, you'd use a toast library)
      achievementCheck.newAchievements.forEach(achievement => {
        console.log(`🎉 New achievement unlocked: ${achievement.title}!`);
      });
    }

    setCurrentSession(null);
    setCurrentScreen('home');
  };

  const handleBack = () => {
    setCurrentSession(null);
    setCurrentScreen('home');
  };

  const handleStudyCharacter = (characterId: string) => {
    // Create a single character quiz session
    const characterQuiz = quizzes.find(q => q.character_id === characterId);
    if (characterQuiz) {
      const session: LearningSession = {
        id: `session_${Date.now()}`,
        cards: [characterQuiz],
        completed: 0,
        correct: 0,
        start_time: new Date()
      };
      setCurrentSession(session);
      setCurrentScreen('quiz');
    }
  };

  if (currentScreen === 'quiz' && currentSession) {
    return (
      <div className="min-h-screen bg-background">
        <QuizScreen
          quizzes={currentSession.cards}
          characters={characters}
          radicals={radicals}
          onComplete={handleQuizComplete}
          onBack={handleBack}
        />
      </div>
    );
  }

  if (currentScreen === 'vocabulary') {
    return (
      <div className="min-h-screen bg-background">
        <VocabularyScreen
          characters={characters}
          radicals={radicals}
          learnedCharacters={learnedCharacters}
          onBack={() => setCurrentScreen('home')}
          onStudyCharacter={handleStudyCharacter}
        />
      </div>
    );
  }

  if (currentScreen === 'achievements') {
    return (
      <div className="min-h-screen bg-background">
        <AchievementScreen
          achievements={userProgress.achievements || []}
          userProgress={userProgress}
          onBack={() => setCurrentScreen('home')}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <HomeScreen
        userProgress={userProgress}
        dueCards={dueCards.length}
        newCards={newCards.length}
        onStartQuickMatch={startQuickMatch}
        onStartLearningSet={startLearningSet}
        onStartReview={startReview}
        onNavigateToVocabulary={() => setCurrentScreen('vocabulary')}
        onNavigateToAchievements={() => setCurrentScreen('achievements')}
      />
    </div>
  );
}