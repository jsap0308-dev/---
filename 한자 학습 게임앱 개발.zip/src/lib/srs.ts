import { SRSCard } from './types';

const INITIAL_EASE_FACTOR = 2.5;
const MIN_EASE_FACTOR = 1.3;
const EASE_FACTOR_MODIFIER = 0.1;

export function createNewCard(characterId: string): SRSCard {
  return {
    character_id: characterId,
    ease_factor: INITIAL_EASE_FACTOR,
    interval: 1,
    next_review: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
    review_count: 0,
    streak: 0
  };
}

export function updateCard(
  card: SRSCard, 
  performance: 'again' | 'hard' | 'good' | 'easy'
): SRSCard {
  const now = new Date();
  let newInterval = card.interval;
  let newEaseFactor = card.ease_factor;
  let newStreak = card.streak;

  switch (performance) {
    case 'again':
      newInterval = 1;
      newEaseFactor = Math.max(
        MIN_EASE_FACTOR,
        card.ease_factor - 0.2
      );
      newStreak = 0;
      break;
    
    case 'hard':
      newInterval = Math.max(1, Math.floor(card.interval * 1.2));
      newEaseFactor = Math.max(
        MIN_EASE_FACTOR,
        card.ease_factor - EASE_FACTOR_MODIFIER
      );
      newStreak = card.streak + 1;
      break;
    
    case 'good':
      if (card.review_count === 0) {
        newInterval = 1;
      } else if (card.review_count === 1) {
        newInterval = 6;
      } else {
        newInterval = Math.round(card.interval * card.ease_factor);
      }
      newStreak = card.streak + 1;
      break;
    
    case 'easy':
      if (card.review_count === 0) {
        newInterval = 4;
      } else {
        newInterval = Math.round(card.interval * card.ease_factor * 1.3);
      }
      newEaseFactor = card.ease_factor + EASE_FACTOR_MODIFIER;
      newStreak = card.streak + 1;
      break;
  }

  return {
    ...card,
    ease_factor: newEaseFactor,
    interval: newInterval,
    next_review: new Date(now.getTime() + newInterval * 24 * 60 * 60 * 1000),
    review_count: card.review_count + 1,
    last_reviewed: now,
    streak: newStreak
  };
}

export function getDueCards(cards: SRSCard[]): SRSCard[] {
  const now = new Date();
  return cards.filter(card => card.next_review <= now);
}

export function getNewCards(cards: SRSCard[], limit: number = 5): SRSCard[] {
  return cards
    .filter(card => card.review_count === 0)
    .slice(0, limit);
}

export function calculateRetention(cards: SRSCard[]): number {
  const reviewedCards = cards.filter(card => card.review_count > 0);
  if (reviewedCards.length === 0) return 0;
  
  const retainedCards = reviewedCards.filter(card => card.streak > 0);
  return (retainedCards.length / reviewedCards.length) * 100;
}