import { Character } from './types';

// 발음 오디오 관리 클래스
export class AudioManager {
  private static instance: AudioManager;
  private cache: Map<string, HTMLAudioElement> = new Map();
  private isPlaying: boolean = false;

  static getInstance(): AudioManager {
    if (!AudioManager.instance) {
      AudioManager.instance = new AudioManager();
    }
    return AudioManager.instance;
  }

  // Web Speech API를 사용한 발음 재생
  async playPronunciation(character: Character, language: 'chinese' | 'korean' | 'japanese' = 'chinese'): Promise<void> {
    if (this.isPlaying) return;

    try {
      this.isPlaying = true;

      if ('speechSynthesis' in window) {
        let text: string;
        let lang: string;

        switch (language) {
          case 'chinese':
            text = character.pronunciation.pinyin;
            lang = 'zh-CN';
            break;
          case 'korean':
            text = character.pronunciation.korean;
            lang = 'ko-KR';
            break;
          case 'japanese':
            text = character.pronunciation.japanese_on;
            lang = 'ja-JP';
            break;
        }

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = lang;
        utterance.rate = 0.7;
        utterance.pitch = 1.0;
        utterance.volume = 0.8;

        utterance.onend = () => {
          this.isPlaying = false;
        };

        utterance.onerror = () => {
          this.isPlaying = false;
          console.warn('Speech synthesis failed, using fallback');
          this.playFallbackAudio(character);
        };

        speechSynthesis.speak(utterance);
      } else {
        this.playFallbackAudio(character);
      }
    } catch (error) {
      this.isPlaying = false;
      console.error('Failed to play pronunciation:', error);
    }
  }

  // 오디오 파일을 사용한 발음 재생 (실제 구현에서는 서버에서 오디오 파일 제공)
  async playAudioFile(character: Character): Promise<void> {
    if (this.isPlaying) return;

    try {
      const audioUrl = character.pronunciation.audio_url;
      if (!audioUrl) {
        await this.playPronunciation(character);
        return;
      }

      let audio = this.cache.get(audioUrl);
      
      if (!audio) {
        audio = new Audio(audioUrl);
        audio.preload = 'auto';
        this.cache.set(audioUrl, audio);
      }

      this.isPlaying = true;
      
      audio.onended = () => {
        this.isPlaying = false;
      };

      audio.onerror = () => {
        this.isPlaying = false;
        console.warn('Audio file failed to load, using speech synthesis');
        this.playPronunciation(character);
      };

      await audio.play();
    } catch (error) {
      this.isPlaying = false;
      console.error('Failed to play audio file:', error);
      // Fallback to speech synthesis
      await this.playPronunciation(character);
    }
  }

  // 폴백 오디오 재생 (비프음 등)
  private playFallbackAudio(character: Character): void {
    try {
      // Web Audio API를 사용한 간단한 비프음
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.2);

      setTimeout(() => {
        this.isPlaying = false;
      }, 200);
    } catch (error) {
      console.error('Fallback audio failed:', error);
      this.isPlaying = false;
    }
  }

  // 캐시 정리
  clearCache(): void {
    this.cache.clear();
  }

  // 현재 재생 중인지 확인
  getIsPlaying(): boolean {
    return this.isPlaying;
  }

  // 재생 중단
  stop(): void {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    this.cache.forEach(audio => {
      audio.pause();
      audio.currentTime = 0;
    });
    this.isPlaying = false;
  }
}

// 전역 오디오 매니저 인스턴스
export const audioManager = AudioManager.getInstance();

// 발음 재생 헬퍼 함수들
export const playChinesePronunciation = (character: Character) => {
  return audioManager.playPronunciation(character, 'chinese');
};

export const playKoreanPronunciation = (character: Character) => {
  return audioManager.playPronunciation(character, 'korean');
};

export const playJapanesePronunciation = (character: Character) => {
  return audioManager.playPronunciation(character, 'japanese');
};

// 선호 언어에 따른 발음 재생
export const playPreferredPronunciation = (character: Character, preferredLanguage?: 'chinese' | 'korean' | 'japanese') => {
  const language = preferredLanguage || 'chinese';
  return audioManager.playPronunciation(character, language);
};