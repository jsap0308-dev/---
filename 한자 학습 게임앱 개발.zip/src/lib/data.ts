import { Radical, Character, Quiz, Achievement } from './types';

export const radicals: Radical[] = [
  {
    id: 'water',
    glyph: '水',
    pronunciation: 'shuǐ',
    meaning: '물',
    examples: ['江', '河', '海', '湖', '汽', '汗', '池', '沙'],
    stroke_count: 4
  },
  {
    id: 'tree',
    glyph: '木',
    pronunciation: 'mù',
    meaning: '나무',
    examples: ['林', '森', '果', '根', '桃', '梅', '桂', '柱'],
    stroke_count: 4
  },
  {
    id: 'fire',
    glyph: '火',
    pronunciation: 'huǒ',
    meaning: '불',
    examples: ['燒', '燈', '炎', '烤', '煙', '燃', '熱', '焰'],
    stroke_count: 4
  },
  {
    id: 'person',
    glyph: '人',
    pronunciation: 'rén',
    meaning: '사람',
    examples: ['仁', '他', '們', '休', '伸', '位', '住', '作'],
    stroke_count: 2
  },
  {
    id: 'earth',
    glyph: '土',
    pronunciation: 'tǔ',
    meaning: '흙',
    examples: ['地', '坐', '城', '場', '坂', '坡', '基', '墓'],
    stroke_count: 3
  },
  {
    id: 'hand',
    glyph: '手',
    pronunciation: 'shǒu',
    meaning: '손',
    examples: ['拿', '打', '抓', '推', '拍', '拉', '持', '指'],
    stroke_count: 4
  },
  {
    id: 'heart',
    glyph: '心',
    pronunciation: 'xīn',
    meaning: '마음',
    examples: ['思', '想', '愛', '忙', '忘', '快', '悲', '恨'],
    stroke_count: 4
  },
  {
    id: 'mouth',
    glyph: '口',
    pronunciation: 'kǒu',
    meaning: '입',
    examples: ['名', '吃', '呼', '唱', '問', '回', '國', '語'],
    stroke_count: 3
  },
  {
    id: 'sun',
    glyph: '日',
    pronunciation: 'rì',
    meaning: '해',
    examples: ['明', '時', '早', '春', '昨', '晚', '暗', '曉'],
    stroke_count: 4
  },
  {
    id: 'moon',
    glyph: '月',
    pronunciation: 'yuè',
    meaning: '달',
    examples: ['明', '期', '有', '服', '朋', '望', '朝', '肉'],
    stroke_count: 4
  }
];

export const characters: Character[] = [
  // 8급 한자
  {
    id: 'river',
    character: '江',
    radical_id: 'water',
    pronunciation: {
      pinyin: 'jiāng',
      korean: '강',
      japanese_on: 'こう',
      japanese_kun: 'え'
    },
    meaning: {
      korean: '강',
      english: 'river'
    },
    examples: ['長江', '江南', '江戶'],
    difficulty: 2,
    grade: 8,
    frequency: 85,
    tags: ['자연', '지리'],
    etymology: '물(水) + 공(工)의 합자. 물이 흐르는 큰 강을 의미'
  },
  {
    id: 'forest',
    character: '林',
    radical_id: 'tree',
    pronunciation: {
      pinyin: 'lín',
      korean: '림',
      japanese_on: 'りん',
      japanese_kun: 'はやし'
    },
    meaning: {
      korean: '숲',
      english: 'forest'
    },
    examples: ['森林', '林業', '桂林'],
    difficulty: 1,
    grade: 8,
    frequency: 92,
    tags: ['자연', '식물'],
    etymology: '나무(木) 두 개가 합쳐져서 숲을 나타냄'
  },
  {
    id: 'bright',
    character: '明',
    radical_id: 'sun',
    pronunciation: {
      pinyin: 'míng',
      korean: '명',
      japanese_on: 'めい',
      japanese_kun: 'あかるい'
    },
    meaning: {
      korean: '밝다',
      english: 'bright'
    },
    examples: ['明日', '明白', '發明'],
    difficulty: 2,
    grade: 7,
    frequency: 98,
    tags: ['기본', '날씨'],
    etymology: '해(日)와 달(月)이 합쳐져 밝음을 나타냄'
  },
  {
    id: 'love',
    character: '愛',
    radical_id: 'heart',
    pronunciation: {
      pinyin: 'ài',
      korean: '애',
      japanese_on: 'あい',
      japanese_kun: 'いとしい'
    },
    meaning: {
      korean: '사랑',
      english: 'love'
    },
    examples: ['愛情', '愛人', '可愛'],
    difficulty: 3,
    grade: 6,
    frequency: 95,
    tags: ['감정', '기본'],
    etymology: '마음과 받아들임을 나타내는 복합 문자'
  },
  {
    id: 'country',
    character: '國',
    radical_id: 'mouth',
    pronunciation: {
      pinyin: 'guó',
      korean: '국',
      japanese_on: 'こく',
      japanese_kun: 'くに'
    },
    meaning: {
      korean: '나라',
      english: 'country'
    },
    examples: ['中國', '韓國', '外國'],
    difficulty: 3,
    grade: 5,
    frequency: 99,
    tags: ['정치', '지리'],
    etymology: '경계 안의 영토와 사람들을 나타냄'
  },
  // 4급 한자
  {
    id: 'virtue',
    character: '德',
    radical_id: 'heart',
    pronunciation: {
      pinyin: 'dé',
      korean: '덕',
      japanese_on: 'とく',
      japanese_kun: ''
    },
    meaning: {
      korean: '덕',
      english: 'virtue'
    },
    examples: ['道德', '品德', '德行'],
    difficulty: 4,
    grade: 4,
    frequency: 78,
    tags: ['철학', '윤리'],
    etymology: '곧은 마음과 행동을 나타내는 복합 문자'
  },
  {
    id: 'wisdom',
    character: '智',
    radical_id: 'mouth',
    pronunciation: {
      pinyin: 'zhì',
      korean: '지',
      japanese_on: 'ち',
      japanese_kun: ''
    },
    meaning: {
      korean: '지혜',
      english: 'wisdom'
    },
    examples: ['智慧', '知識', '智能'],
    difficulty: 4,
    grade: 4,
    frequency: 82,
    tags: ['지식', '철학'],
    etymology: '알다(知)와 일(日)이 합쳐진 지혜를 나타내는 문자'
  },
  // 3급 한자
  {
    id: 'righteousness',
    character: '義',
    radical_id: 'person',
    pronunciation: {
      pinyin: 'yì',
      korean: '의',
      japanese_on: 'ぎ',
      japanese_kun: ''
    },
    meaning: {
      korean: '의',
      english: 'righteousness'
    },
    examples: ['正義', '義務', '意義'],
    difficulty: 4,
    grade: 3,
    frequency: 75,
    tags: ['철학', '윤리'],
    etymology: '양(羊)과 나(我)가 합쳐진 올바름을 나타내는 문자'
  },
  {
    id: 'sincerity',
    character: '誠',
    radical_id: 'mouth',
    pronunciation: {
      pinyin: 'chéng',
      korean: '성',
      japanese_on: 'せい',
      japanese_kun: 'まこと'
    },
    meaning: {
      korean: '성실',
      english: 'sincerity'
    },
    examples: ['誠實', '至誠', '誠意'],
    difficulty: 5,
    grade: 3,
    frequency: 68,
    tags: ['윤리', '성격'],
    etymology: '말(言)과 이루다(成)가 합쳐진 진실한 말을 나타냄'
  },
  // 2급 한자
  {
    id: 'benevolence',
    character: '仁',
    radical_id: 'person',
    pronunciation: {
      pinyin: 'rén',
      korean: '인',
      japanese_on: 'じん',
      japanese_kun: ''
    },
    meaning: {
      korean: '어 iar',
      english: 'benevolence'
    },
    examples: ['仁愛', '仁德', '仁慈'],
    difficulty: 5,
    grade: 2,
    frequency: 65,
    tags: ['철학', '윤리'],
    etymology: '사람(人)과 둘(二)이 합쳐진 사람 간의 사랑을 나타냄'
  },
  // 1급 한자
  {
    id: 'propriety',
    character: '禮',
    radical_id: 'mouth',
    pronunciation: {
      pinyin: 'lǐ',
      korean: '례',
      japanese_on: 'れい',
      japanese_kun: ''
    },
    meaning: {
      korean: '예의',
      english: 'propriety'
    },
    examples: ['禮儀', '禮節', '禮貌'],
    difficulty: 5,
    grade: 1,
    frequency: 58,
    tags: ['윤리', '사회'],
    etymology: '신에게 제사 지내는 의식에서 유래된 예의범절을 나타냄'
  },
  {
    id: 'cultivate',
    character: '修',
    radical_id: 'person',
    pronunciation: {
      pinyin: 'xiū',
      korean: '수',
      japanese_on: 'しゅう',
      japanese_kun: 'おさめる'
    },
    meaning: {
      korean: '닦다',
      english: 'cultivate'
    },
    examples: ['修養', '修練', '修行'],
    difficulty: 5,
    grade: 1,
    frequency: 61,
    tags: ['교육', '철학'],
    etymology: '사람이 자신을 바르게 세우는 모습을 나타냄'
  }
];

// 성취 배지 시스템
export const achievements: Achievement[] = [
  {
    id: 'first_step',
    title: '첫 걸음',
    description: '첫 번째 한자를 학습하세요',
    icon: '🌱',
    condition: {
      type: 'total_learned',
      target: 1
    },
    unlocked: false,
    xp_reward: 50
  },
  {
    id: 'week_warrior',
    title: '일주일 전사',
    description: '7일 연속 학습하세요',
    icon: '🔥',
    condition: {
      type: 'streak',
      target: 7
    },
    unlocked: false,
    xp_reward: 200
  },
  {
    id: 'hundred_club',
    title: '백자 클럽',
    description: '100개의 한자를 학습하세요',
    icon: '💯',
    condition: {
      type: 'total_learned',
      target: 100
    },
    unlocked: false,
    xp_reward: 500
  },
  {
    id: 'grade_8_master',
    title: '8급 마스터',
    description: '8급 한자를 모두 마스터하세요',
    icon: '🥉',
    condition: {
      type: 'grade_complete',
      target: 8
    },
    unlocked: false,
    xp_reward: 300
  },
  {
    id: 'grade_1_master',
    title: '1급 마스터',
    description: '1급 한자를 모두 마스터하세요',
    icon: '🏆',
    condition: {
      type: 'grade_complete',
      target: 1
    },
    unlocked: false,
    xp_reward: 2000
  },
  {
    id: 'speed_demon',
    title: '번개 손',
    description: '평균 3초 이하로 답변하세요',
    icon: '⚡',
    condition: {
      type: 'speed',
      target: 3000
    },
    unlocked: false,
    xp_reward: 400
  },
  {
    id: 'perfectionist',
    title: '완벽주의자',
    description: '정확도 95% 이상 달성하세요',
    icon: '🎯',
    condition: {
      type: 'accuracy',
      target: 95
    },
    unlocked: false,
    xp_reward: 600
  }
];

export const quizzes: Quiz[] = [
  {
    id: 'quiz_river_1',
    character_id: 'river',
    type: 'multiple_choice',
    question: '물(水) 부수를 가진 이 한자의 뜻은?',
    options: ['강', '산', '하늘', '땅'],
    correct_answer: 0,
    explanation: '江은 물 부수에 공(工)이 합쳐진 글자로 "강"을 의미합니다.',
    radical_hint: '水 (물)'
  },
  {
    id: 'quiz_forest_1',
    character_id: 'forest',
    type: 'radical_guess',
    question: '林의 부수는 무엇일까요?',
    options: ['水', '木', '火', '土'],
    correct_answer: 1,
    explanation: '林은 나무(木) 두 개가 합쳐져 숲을 나타내는 글자입니다.',
    radical_hint: '나무 두 그루가 모여있으면?'
  },
  {
    id: 'quiz_lamp_1',
    character_id: 'lamp',
    type: 'multiple_choice',
    question: '燈의 한국어 뜻은?',
    options: ['불', '등불', '태양', '별'],
    correct_answer: 1,
    explanation: '燈은 불(火) 부수에 등(登)이 합쳐져 "등불"을 의미합니다.',
    radical_hint: '火 (불)'
  },
  {
    id: 'quiz_rest_1',
    character_id: 'rest',
    type: 'meaning_match',
    question: '休의 어원적 의미는?',
    options: ['사람이 서있다', '사람이 나무에 기댄다', '��람이 뛴다', '사람이 앉는다'],
    correct_answer: 1,
    explanation: '休는 사람(人)이 나무(木)에 기대어 쉬는 모습을 형상화한 글자입니다.',
    radical_hint: '人 (사람)'
  }
];