export interface Radical {
  id: string;
  glyph: string;
  pronunciation: string;
  meaning: string;
  examples: string[];
  stroke_count: number;
}

export interface Character {
  id: string;
  character: string;
  radical_id: string;
  pronunciation: {
    pinyin: string;
    korean: string;
    japanese_on: string;
    japanese_kun: string;
    audio_url?: string;  // 발음 오디오 URL 추가
  };
  meaning: {
    korean: string;
    english: string;
  };
  examples: string[];
  difficulty: 1 | 2 | 3 | 4 | 5;
  etymology?: string;
  grade?: number;  // 한자 급수 (1-8급)
  frequency?: number;  // 사용 빈도
  tags?: string[];  // 테마 태그
}

export interface Quiz {
  id: string;
  character_id: string;
  type: 'multiple_choice' | 'radical_guess' | 'meaning_match';
  question: string;
  options: string[];
  correct_answer: number;
  explanation: string;
  radical_hint?: string;
}

export interface SRSCard {
  character_id: string;
  ease_factor: number;
  interval: number;
  next_review: Date;
  review_count: number;
  last_reviewed?: Date;
  streak: number;
}

export interface LearningSession {
  id: string;
  cards: Quiz[];
  completed: number;
  correct: number;
  start_time: Date;
  theme?: string;
}

export interface UserProgress {
  total_learned: number;
  daily_streak: number;
  weekly_xp: number;
  level: number;
  coins: number;
  badges: string[];
  achievements?: Achievement[];  // 성취 시스템 추가
}

// 성취 배지 시스템
export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  condition: {
    type: 'streak' | 'total_learned' | 'accuracy' | 'speed' | 'grade_complete';
    target: number;
    current?: number;
  };
  unlocked: boolean;
  unlocked_date?: Date;
  xp_reward: number;
}

// 필터링 옵션
export interface VocabularyFilter {
  search?: string;
  radical?: string;
  grade?: number;
  difficulty?: number;
  tags?: string[];
  learned?: boolean;
}