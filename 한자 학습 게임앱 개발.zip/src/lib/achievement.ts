import { Achievement, UserProgress, SRSCard } from './types';
import { achievements as initialAchievements } from './data';

export interface AchievementCheckResult {
  newAchievements: Achievement[];
  updatedAchievements: Achievement[];
  totalXP: number;
}

// 성취 상태 확인 및 업데이트
export function checkAchievements(
  userProgress: UserProgress,
  srsCards: SRSCard[],
  sessionStats?: {
    accuracy: number;
    averageTime: number;
    completedGrades: number[];
  }
): AchievementCheckResult {
  const currentAchievements = userProgress.achievements || [...initialAchievements];
  const newAchievements: Achievement[] = [];
  const updatedAchievements: Achievement[] = [];
  let totalXP = 0;

  currentAchievements.forEach(achievement => {
    if (achievement.unlocked) return;

    const shouldUnlock = evaluateAchievementCondition(
      achievement,
      userProgress,
      srsCards,
      sessionStats
    );

    if (shouldUnlock) {
      const unlockedAchievement: Achievement = {
        ...achievement,
        unlocked: true,
        unlocked_date: new Date()
      };

      newAchievements.push(unlockedAchievement);
      totalXP += achievement.xp_reward;
    } else {
      // 진행률 업데이트
      const progress = calculateAchievementProgress(
        achievement,
        userProgress,
        srsCards,
        sessionStats
      );

      if (progress !== achievement.condition.current) {
        const updatedAchievement: Achievement = {
          ...achievement,
          condition: {
            ...achievement.condition,
            current: progress
          }
        };
        updatedAchievements.push(updatedAchievement);
      }
    }
  });

  return {
    newAchievements,
    updatedAchievements,
    totalXP
  };
}

// 성취 조건 평가
function evaluateAchievementCondition(
  achievement: Achievement,
  userProgress: UserProgress,
  srsCards: SRSCard[],
  sessionStats?: {
    accuracy: number;
    averageTime: number;
    completedGrades: number[];
  }
): boolean {
  const { type, target } = achievement.condition;

  switch (type) {
    case 'total_learned':
      return userProgress.total_learned >= target;
    
    case 'streak':
      return userProgress.daily_streak >= target;
    
    case 'accuracy':
      if (!sessionStats) return false;
      return sessionStats.accuracy >= target;
    
    case 'speed':
      if (!sessionStats) return false;
      return sessionStats.averageTime <= target;
    
    case 'grade_complete':
      if (!sessionStats) return false;
      return sessionStats.completedGrades.includes(target);
    
    default:
      return false;
  }
}

// 성취 진행률 계산
function calculateAchievementProgress(
  achievement: Achievement,
  userProgress: UserProgress,
  srsCards: SRSCard[],
  sessionStats?: {
    accuracy: number;
    averageTime: number;
    completedGrades: number[];
  }
): number {
  const { type, target } = achievement.condition;

  switch (type) {
    case 'total_learned':
      return userProgress.total_learned;
    
    case 'streak':
      return userProgress.daily_streak;
    
    case 'accuracy':
      return sessionStats?.accuracy || 0;
    
    case 'speed':
      return sessionStats?.averageTime || 0;
    
    case 'grade_complete':
      // 특정 급수의 완료 상태를 0 또는 target으로 반환
      return sessionStats?.completedGrades.includes(target) ? target : 0;
    
    default:
      return 0;
  }
}

// 급수별 완료 상태 확인
export function checkGradeCompletion(srsCards: SRSCard[], characters: any[]): number[] {
  const completedGrades: number[] = [];
  
  // 각 급수별로 모든 한자가 학습되었는지 확인
  for (let grade = 1; grade <= 8; grade++) {
    const gradeCharacters = characters.filter(char => char.grade === grade);
    const learnedInGrade = srsCards.filter(card => {
      const character = characters.find(char => char.id === card.character_id);
      return character?.grade === grade && card.review_count > 0;
    });

    if (gradeCharacters.length > 0 && learnedInGrade.length === gradeCharacters.length) {
      completedGrades.push(grade);
    }
  }

  return completedGrades;
}

// 세션 통계 계산
export function calculateSessionStats(
  sessionResults: Array<{
    isCorrect: boolean;
    timeSpent: number;
    characterId: string;
  }>,
  characters: any[]
): {
  accuracy: number;
  averageTime: number;
  completedGrades: number[];
} {
  if (sessionResults.length === 0) {
    return {
      accuracy: 0,
      averageTime: 0,
      completedGrades: []
    };
  }

  const correctAnswers = sessionResults.filter(result => result.isCorrect).length;
  const accuracy = (correctAnswers / sessionResults.length) * 100;
  
  const totalTime = sessionResults.reduce((sum, result) => sum + result.timeSpent, 0);
  const averageTime = totalTime / sessionResults.length;

  // 이 세션에서 다룬 급수들 (실제로는 더 복잡한 로직 필요)
  const sessionCharacterIds = sessionResults.map(result => result.characterId);
  const sessionCharacters = characters.filter(char => sessionCharacterIds.includes(char.id));
  const sessionGrades = [...new Set(sessionCharacters.map(char => char.grade))].filter(Boolean);

  return {
    accuracy,
    averageTime,
    completedGrades: sessionGrades // 임시로 세션에 포함된 급수들 반환
  };
}

// 성취 알림 데이터 생성
export function createAchievementNotification(achievement: Achievement): {
  title: string;
  message: string;
  icon: string;
  xp: number;
} {
  return {
    title: `🎉 새로운 배지 획득!`,
    message: `"${achievement.title}" 배지를 획득했습니다! ${achievement.description}`,
    icon: achievement.icon,
    xp: achievement.xp_reward
  };
}

// 전체 진행률 계산
export function calculateOverallProgress(achievements: Achievement[]): {
  unlockedCount: number;
  totalCount: number;
  percentage: number;
  totalXP: number;
} {
  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const totalXP = unlockedAchievements.reduce((sum, a) => sum + a.xp_reward, 0);

  return {
    unlockedCount: unlockedAchievements.length,
    totalCount: achievements.length,
    percentage: (unlockedAchievements.length / achievements.length) * 100,
    totalXP
  };
}