    meaning: {
      korean: '어짊',
      english: 'benevolence'
    },